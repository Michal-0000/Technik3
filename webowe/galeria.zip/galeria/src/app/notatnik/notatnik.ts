import { Component } from '@angular/core';

@Component({
  selector: 'app-notatnik',
  imports: [],
  templateUrl: './notatnik.html',
  styleUrl: './notatnik.css',
})
export class Notatnik {

}
