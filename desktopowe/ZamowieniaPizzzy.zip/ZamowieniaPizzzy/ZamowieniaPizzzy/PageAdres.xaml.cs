﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ZamowieniaPizzzy
{
    /// <summary>
    /// Logika interakcji dla klasy PageAdres.xaml
    /// </summary>
    public partial class PageAdres : Page
    {
        MainWindow main;
        public PageAdres(MainWindow mainWindow)
        {
            InitializeComponent();
            this.main = mainWindow;
        }

        private void Dalej_Click(object sender, RoutedEventArgs e)
        {
            main.frame.Navigate(new PageWybor(main));
        }
    }

    public struct Adres()
    {
        public string imieNazwisko;
        public string ulica;
        public string kod;
        public string miasto;

        //public Adres(string imie, string ulica, string kod, string miasto)
        //{
        //    this.imieNazwisko = imie;
        //    this.ulica = ulica;
        //    this.kod = kod;
        //    this.miasto = miasto;
        //}
    }

}
