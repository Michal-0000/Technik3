﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace SantaDino
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private DispatcherTimer timer = new DispatcherTimer
        {
            Interval = TimeSpan.FromMilliseconds(16.6)

        };
        private List<Tree> trees = new List<Tree>();

        double lastGeneratedTime = 999;
        double currHeight = 0;

        public MainWindow()
        {
            InitializeComponent();
            timer.Tick += TryGenerateTree;
            timer.Start();

        }

        private void TryGenerateTree(object sender, EventArgs e)
        {

        }

        private void OnJump()
        {
            DoubleAnimation upAnimation = new DoubleAnimation
            {
                From = 0,
                To = -50,
                Duration = TimeSpan.FromMilliseconds(200),
                AutoReverse = true,
                EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseOut }
            };

            ImageTransform.BeginAnimation(TranslateTransform.YProperty, upAnimation);
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Space)
            {
                OnJump();
            }
        }

    }

    public class Tree
    {
        public double posX;
        public Image Image;

        public Tree()
        {
            posX = 300;
            Image.Height = 60;
            Image.Width = 60;
            Image.Source = new BitmapImage(new Uri("pack://application:,,,/Images/dino.png"));
        }
    }
}