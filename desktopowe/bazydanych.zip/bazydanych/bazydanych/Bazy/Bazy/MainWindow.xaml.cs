﻿using System.Data;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Npgsql;

namespace Bazy
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private string connectionString = "Host=localhost;Username=postgres;Password=postgres;Database=dbmichal;";

        public MainWindow()
        {
            InitializeComponent();
            ZaladujUczniow();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string imie = txtbImie.Text;
            string nazwisko = txtbNazwisko.Text;
            string plec = (cbPlec.SelectedItem as ComboBoxItem)?.Content.ToString();
            DateTime? dataUr = DataUrodzeniaPicker.SelectedDate;
            if (string.IsNullOrWhiteSpace(imie) || string.IsNullOrWhiteSpace(nazwisko) || string.IsNullOrWhiteSpace(plec) || dataUr == null) {
                MessageBox.Show( "Nie wypełniłeś wszystkich pól...", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            try
            {
                using (var connection = new NpgsqlConnection(connectionString)) { 
                    connection.Open();
                    using (var cmd = new NpgsqlCommand("INSERT INTO uczen (imie, nazwisko, plec, data_ur) VALUES (@imie, @nazwisko, @plec, @data_ur)", connection)) {
                        cmd.Parameters.AddWithValue("imie", imie);
                        cmd.Parameters.AddWithValue("nazwisko", nazwisko);
                        cmd.Parameters.AddWithValue("plec", plec[0]);
                        cmd.Parameters.AddWithValue("data_ur", dataUr.Value);
                        cmd.ExecuteNonQuery();
                    }
                    connection.Close();
                }
                MessageBox.Show("Uczeń został dodany do bazy...", "Dodanie ucznia", MessageBoxButton.OK, MessageBoxImage.Information);

                ZaladujUczniow();
                WyczyscFormularz();
            }
            catch (Exception ex) {
                MessageBox.Show( $"Problem z dodaniem do bazy: {ex.Message}", "Błąd bazy", MessageBoxButton.OK, MessageBoxImage.Error);
            }

        }

        private void WyczyscFormularz() {
            txtbImie.Clear();
            txtbNazwisko.Clear();
            cbPlec.SelectedItem = -1;
            DataUrodzeniaPicker.SelectedDate = null;
        }



        private void ZaladujUczniow() {

            try
            {
                using (var connection = new NpgsqlConnection(connectionString))
                {
                    connection.Open();
                    using (var cmd = new NpgsqlCommand("SELECT id, imie, nazwisko, plec, data_ur FROM uczen", connection))
                    {
                        using (var reader = cmd.ExecuteReader()) {
                            DataTable uczniowieTable = new DataTable();
                            uczniowieTable.Load(reader);
                            UczniowieDataGrid.ItemsSource = uczniowieTable.DefaultView;
                        }
                    }
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Problem z pobraniem rekordów z bazy: {ex.Message}", "Błąd bazy", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if(UczniowieDataGrid.SelectedItem == null)
            {
                MessageBox.Show("Nie wybrałeś żadnego ucznia do usunięcia...", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            DataRowView wybranyWiersz = (DataRowView)UczniowieDataGrid.SelectedItem;
            int id = Convert.ToInt32(wybranyWiersz["id"]);

            MessageBoxResult czyUsunac = MessageBox.Show($"Czy na pewno chcesz usunąć ucznia o ID {id}?", "Potwierdzenie usunięcia", MessageBoxButton.YesNo, MessageBoxImage.Warning);

            if(czyUsunac != MessageBoxResult.Yes) { return; }
            try
            {
                using (var connection = new NpgsqlConnection(connectionString))
                {
                    connection.Open();
                    using (var cmd = new NpgsqlCommand("DELETE FROM uczen WHERE id = @id", connection))
                    {
                        cmd.Parameters.AddWithValue("id", id);
                        cmd.ExecuteNonQuery();
                    }
                    connection.Close();
                    ZaladujUczniow();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show($"Problem z usunięciem rekordu {ex}", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Button_Click_edit(object sender, RoutedEventArgs e)
        {
            string imie = txtbImie.Text;
            string nazwisko = txtbNazwisko.Text;
            string plec = (cbPlec.SelectedItem as ComboBoxItem)?.Content.ToString();
            DateTime? dataUr = DataUrodzeniaPicker.SelectedDate;
            if (string.IsNullOrWhiteSpace(imie) || string.IsNullOrWhiteSpace(nazwisko) || string.IsNullOrWhiteSpace(plec) || dataUr == null)
            {
                MessageBox.Show("Nie wypełniłeś wszystkich pól...", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if (UczniowieDataGrid.SelectedItem == null)
            {
                MessageBox.Show("Nie wybrałeś żadnego ucznia do usunięcia...", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }


            DataRowView wybranyWiersz = (DataRowView)UczniowieDataGrid.SelectedItem;
            int id = Convert.ToInt32(wybranyWiersz["id"]);

            try
            {
                using (var connection = new NpgsqlConnection(connectionString))
                {
                    connection.Open();
                    using (var cmd = new NpgsqlCommand("UPDATE uczen SET imie = @imie, nazwisko = @nazwisko, plec = @plec, data_ur = @data_ur WHERE id = @id", connection))
                    {
                        cmd.Parameters.AddWithValue("id", id);
                        cmd.Parameters.AddWithValue("imie", imie);
                        cmd.Parameters.AddWithValue("nazwisko", nazwisko);
                        cmd.Parameters.AddWithValue("plec", plec[0]);
                        cmd.Parameters.AddWithValue("data_ur", dataUr.Value);
                        cmd.ExecuteNonQuery();
                    }
                    connection.Close();
                    MessageBox.Show("Edytowano dane", "Edytowanie", MessageBoxButton.OK, MessageBoxImage.Information);
                    ZaladujUczniow();
                    WyczyscFormularz();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Problem z edycją rekordu {ex}", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Click_MenuItem_Edit(object sender, RoutedEventArgs e)
        {
            Button_Click_edit(sender, e);
        }

        private void Click_MenuItem_Delete(object sender, RoutedEventArgs e)
        {
            Button_Click_1(sender, e);
        }




    }
}